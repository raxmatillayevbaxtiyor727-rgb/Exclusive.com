# EXCLUSIVE sayti — Netlify'ga joylash

Fayllar: index.html (sayt), admin.html (/admin.html), netlify/functions/api.js (backend), netlify.toml, package.json.

## Joylash
1. Papkani GitHub'ga yuklang (Netlify "Import from Git" kerak: funksiyalar oddiy drag-and-drop bilan ishlamaydi) va Netlify'da ulang.
2. Site configuration > Environment variables:
   - ADMIN_PASSWORD — admin paroli (uzun va noyob)
   - TELEGRAM_BOT_TOKEN — @BotFather bergan token (ixtiyoriy)
   - TELEGRAM_CHAT_ID — buyurtma keladigan chat/foydalanuvchi ID (ixtiyoriy)
3. Deploy qiling. Admin: https://SAYT/admin.html
4. Admin panelda telefon, Telegram, Instagram va yetkazib berish matnini kiriting.

Ma’lumotlar (mahsulot, buyurtma, sozlamalar) Netlify Blobs'da doimiy saqlanadi.
Telegram'ni sozlamasangiz ham buyurtmalar admin panelda saqlanadi.
Telegram chat ID olish: botga /start yozing, so‘ng @userinfobot orqali o‘z ID'ingizni bilib oling.
