import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
export const config = { path: "/api/*" };
const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });
const key = () => process.env.ADMIN_PASSWORD || "";
const sign = (t) => crypto.createHmac("sha256", key() + "|exclusive").update(t).digest("hex");
const isAdmin = (r) => {
  const [t, s] = (r.headers.get("authorization") || "").replace("Bearer ", "").split(".");
  return !!(key() && t && s && s.length === 64 && Number(t) > Date.now() && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(sign(t))));
};
const T = (v, n = 200) => String(v ?? "").trim().slice(0, n);
const list = async (st) => {
  const { blobs } = await st.list();
  return (await Promise.all(blobs.map((b) => st.get(b.key, { type: "json" })))).filter(Boolean);
};
async function telegram(text) {
  const tk = process.env.TELEGRAM_BOT_TOKEN, chat = process.env.TELEGRAM_CHAT_ID;
  if (!tk || !chat) return "not_configured";
  try {
    const r = await fetch(`https://api.telegram.org/bot${tk}/sendMessage`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ chat_id: chat, text }) });
    return r.ok ? "sent" : "failed";
  } catch { return "failed"; }
}
export default async (req) => {
  const url = new URL(req.url), route = url.pathname.replace(/^\/(\.netlify\/functions\/api|api)\/?/, "").replace(/\/$/, ""), m = req.method;
  let P, O, C;
  const init = () => { P = getStore("products"); O = getStore("orders"); C = getStore("config"); };
  const body = ["POST", "PUT"].includes(m) ? await req.json().catch(() => ({})) : {};
  try {
    if (route === "health") {
      let db = "ok";
      try { init(); await C.get("ping"); } catch (e) { db = "xato: " + e.message; }
      return J({ ok: true, adminPasswordSet: !!key(), telegramConfigured: !!(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID), db });
    }
    if (route === "login" && m === "POST") {
      if (!key()) return J({ error: "ADMIN_PASSWORD sozlanmagan (Netlify > Environment variables)" }, 500);
      const a = Buffer.from(String(body.password || "")), b = Buffer.from(key());
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return J({ error: "Parol noto‘g‘ri" }, 401);
      const t = String(Date.now() + 864e5);
      return J({ token: t + "." + sign(t) });
    }
    init();
    if (route === "settings" && m === "GET") return J((await C.get("settings", { type: "json" })) || {});
    if (route === "products" && m === "GET") {
      const all = isAdmin(req) && url.searchParams.get("all");
      return J((await list(P)).filter((p) => all || p.visible !== false).sort((a, b) => (a.ts || 0) - (b.ts || 0)));
    }
    if (route === "order" && m === "POST") {
      const o = { id: "o" + Date.now(), ts: Date.now(), name: T(body.name, 100), phone: T(body.phone, 30), tg: T(body.tg, 50), car: T(body.car, 80), year: T(body.year, 10), product: T(body.product, 150), price: T(body.price, 40), wish: T(body.wish, 300), address: T(body.address, 300), note: T(body.note, 500) };
      if (!o.name || !/^[+\d\s()-]{7,20}$/.test(o.phone) || !o.car || !o.year || !o.address || !o.product) return J({ error: "Majburiy maydonlarni to‘g‘ri to‘ldiring" }, 400);
      await O.setJSON(o.id, o);
      const tg = await telegram(`🛒 Yangi buyurtma\n${o.product} (${o.price})\nIsm: ${o.name}\nTel: ${o.phone}\nTelegram: ${o.tg || "-"}\nAvto: ${o.car}, ${o.year}\nIstak: ${o.wish || "-"}\nManzil: ${o.address}\nIzoh: ${o.note || "-"}`);
      return J({ ok: true, saved: true, telegram: tg });
    }
    if (!isAdmin(req)) return J({ error: "Kirish talab qilinadi" }, 401);
    if (route === "products" && m === "PUT") {
      const p = { id: T(body.id, 40) || "p" + Date.now(), name: T(body.name, 120), car: T(body.car, 80), price: Math.max(0, Number(body.price) || 0), visible: body.visible !== false, cat: T(body.cat, 60), desc: T(body.desc, 2000), img: String(body.img || ""), ts: Number(body.ts) || Date.now() };
      if (!p.name || !p.car) return J({ error: "Nomi va avtomobil modeli kerak" }, 400);
      if (p.img.length > 900000) return J({ error: "Rasm juda katta. Kichikroq rasm tanlang." }, 413);
      if (p.img && !p.img.startsWith("data:image/") && !/^https:\/\//.test(p.img)) return J({ error: "Rasm formati noto‘g‘ri" }, 400);
      await P.setJSON(p.id, p);
      return J({ ok: true });
    }
    if (route === "products" && m === "DELETE") { await P.delete(T(url.searchParams.get("id"), 40)); return J({ ok: true }); }
    if (route === "orders" && m === "GET") return J((await list(O)).sort((a, b) => b.ts - a.ts));
    if (route === "settings" && m === "PUT") {
      const s = {}; for (const k of ["phone", "telegram", "instagram", "delivery", "howto"]) s[k] = T(body[k], 600);
      await C.setJSON("settings", s); return J({ ok: true });
    }
    return J({ error: "Topilmadi" }, 404);
  } catch (e) {
    const db = /blobs|siteid|token|environment/i.test(e.name + " " + e.message);
    return J({ error: db ? "Ma’lumotlar bazasi (Netlify Blobs) bilan ulanishda xato: " + e.message : "Server xatosi: " + e.message, code: db ? "db_error" : "server_error" }, db ? 503 : 500);
  }
};
